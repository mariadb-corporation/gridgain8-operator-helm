# GridGainCluster examples

Sample manifests for the GridGain 8 Kubernetes Operator. Helm is the supported operator install. Download this catalog from `https://gridgain-operator.mariadb.com/examples/manifests.tar.gz`.

Create a license Secret before applying any `GridGainCluster`. The operator does not ship a license:

```bash
kubectl create secret generic gridgaincluster-license \
  --from-file=gridgain-license.xml=/path/to/your/gridgain-license.xml
```

Apply **one** cluster example per namespace. These manifests use 1 replica and
1Gi memory so they fit a local cluster; raise both for production.

`apiVersion` is `gridgain.gridgain.com/v1`.

## GA (default feature gates)

| File | Purpose |
|------|---------|
| `license-secret.example.yaml` | Shape of the license Secret (placeholder only). |
| `gridgaincluster.yaml` | Copy this. Ungated fields only. |
| `gridgaincluster-minimal.yaml` | Smallest valid cluster. |
| `gridgaincluster-openshift.yaml` | OpenShift restricted SCC. See the file header. |
| `gridgaincluster-upgrade.yaml` | `spec.upgrade` reference. |
| `gridgaincluster-networkpolicy.yaml` | Workload NetworkPolicy. |
| `gridgaincluster-scheduling.yaml` | Topology spread and PDB. |
| `gridgaincluster-logging.yaml` | Custom Log4j2 (`spec.logging.log4j2Xml`). |

```bash
kubectl apply -f examples/gridgaincluster.yaml
```

On OpenShift, apply `gridgaincluster-openshift.yaml` instead of
`gridgaincluster.yaml` or `gridgaincluster-minimal.yaml`. The minimal manifest leaves security context
unset, so the operator pins UID 1000 and group 2000, and `restricted-v2`
rejects the pod. The OpenShift manifest sets `podSecurityContext` without
those IDs. The constraint then assigns a UID and `fsGroup` from the namespace
range. The header in that file records why each field is there.

## Alpha (enable the named `--feature-gates`)

See [alpha/README.md](alpha/README.md). Gates are off by default.

| File | Gates |
|------|-------|
| `alpha/gridgaincluster-metrics.yaml` | Metrics |
| `alpha/gridgaincluster-auth.yaml` | Auth |
| `alpha/gridgaincluster-tls.yaml` | CRDTLS (create PKCS12 Secrets first) |
| `alpha/gridgain-alpha-features.yaml` | All six |

## Operator install

Install the charts from `https://gridgain-operator.mariadb.com`. Use these files for overlay values and for a cluster in the operator namespace.

| File | Purpose |
|------|---------|
| `operator/values-single-namespace.yaml` | Helm `currentNamespaceOnly: true`. |
| `operator/gridgaincluster.yaml` | CR for the operator namespace in that mode. |
| `operator/servicemonitor.yaml` | Operator `/metrics` for Prometheus Operator. |
| `operator/values-metrics.yaml` | Helm values that render the chart ServiceMonitor. |

Single-namespace (webhook off, Role not ClusterRole):

```bash
helm repo add gridgain8-operator https://gridgain-operator.mariadb.com
helm upgrade --install gridgain8-operator gridgain8-operator/gridgain8-operator \
  -n gridgain-k8s-operator-system --create-namespace \
  -f examples/operator/values-single-namespace.yaml \
  --version 1.0.0
kubectl apply -n gridgain-k8s-operator-system -f examples/operator/gridgaincluster.yaml
```

## Metrics and monitoring

Operand (Metrics gate on): `alpha/gridgaincluster-metrics.yaml` sets
`metricsEnabled: true` and `prometheus.io/scrape` annotations on port **9000**.

Operator: metrics are unauthenticated HTTP on **8080**
(`…-controller-manager-metrics-service`) — no bearer token. Point a collector
at that Service, or install with `-f examples/operator/values-metrics.yaml`
when the Prometheus Operator CRDs exist, or apply `operator/servicemonitor.yaml`.
Restrict who can reach the port with a NetworkPolicy if needed. That Helm
values file works with cluster-wide and `currentNamespaceOnly` installs.

Proof: `curl http://127.0.0.1:9000/metrics` inside the GridGain pod.
This catalog does not install Prometheus.
