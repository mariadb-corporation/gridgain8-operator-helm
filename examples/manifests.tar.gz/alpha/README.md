# Alpha examples

These manifests fill CR fields gated behind `--feature-gates` (off by default).

Enable the matching Helm values before you apply them.

## Enable gates (Helm)

```bash
helm upgrade --install gridgain8-operator gridgain8-operator/gridgain8-operator \
  --set manager.featureGates.Auth=true \
  --set manager.featureGates.CRDTLS=true \
  --set manager.featureGates.ControlCenter=true \
  --set manager.featureGates.Metrics=true \
  --set manager.featureGates.NamedCaches=true \
  --set manager.featureGates.Persistence=true \
  --version 1.0.0
```

Create `gridgaincluster-license` in the namespace before apply.

| File | Gates |
|------|-------|
| `gridgaincluster-metrics.yaml` | Metrics |
| `gridgaincluster-auth.yaml` | Auth |
| `gridgaincluster-tls.yaml` | CRDTLS — generate PKCS12 Secrets first (see that file) |
| `gridgain-alpha-features.yaml` | All six (TLS left disabled until you add stores) |
